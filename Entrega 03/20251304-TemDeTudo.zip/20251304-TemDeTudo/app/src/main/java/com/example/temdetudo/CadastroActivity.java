package com.example.temdetudo;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class CadastroActivity extends AppCompatActivity {

    EditText edtNome;
    Button btnConfirmar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro);

        edtNome = findViewById(R.id.edtNome);
        btnConfirmar = findViewById(R.id.btnConfirmar);

        btnConfirmar.setOnClickListener(v -> {
            String nome = edtNome.getText().toString();

            if (nome.isEmpty()) {
                Toast.makeText(this, "Digite um nome!", Toast.LENGTH_SHORT).show();
            } else {
                Intent intent = new Intent(this, ConfirmacaoActivity.class);
                intent.putExtra("nomeCliente", nome);
                startActivity(intent);
            }
        });
    }
}
