package com.example.lanchefacil;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class PedidoActivity extends AppCompatActivity {

    EditText edtNome, edtLanche;
    Button btnEnviar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pedido);

        edtNome = findViewById(R.id.edtNome);
        edtLanche = findViewById(R.id.edtLanche);
        btnEnviar = findViewById(R.id.btnEnviar);

        btnEnviar.setOnClickListener(v -> {
            String nome = edtNome.getText().toString();
            String lanche = edtLanche.getText().toString();

            if (nome.isEmpty() || lanche.isEmpty()) {
                Toast.makeText(this, getString(R.string.erro_pedido), Toast.LENGTH_SHORT).show();
            } else {
                Intent intent = new Intent(this, ResumoActivity.class);
                intent.putExtra("nome", nome);
                intent.putExtra("lanche", lanche);
                startActivity(intent);
            }
        });
    }
}
