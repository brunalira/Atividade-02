package com.example.pizzaria;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;

public class SaboresActivity extends AppCompatActivity {

    CheckBox cbCalabresa, cbMarguerita, cbFrango, cbQueijos, cbBaiana;
    Button btnContinuar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sabores);

        cbCalabresa = findViewById(R.id.cbCalabresa);
        cbMarguerita = findViewById(R.id.cbMarguerita);
        cbFrango = findViewById(R.id.cbFrango);
        cbQueijos = findViewById(R.id.cbQueijos);
        cbBaiana = findViewById(R.id.cbBaiana);
        btnContinuar = findViewById(R.id.btnContinuar);

        btnContinuar.setOnClickListener(v -> {
            ArrayList<String> sabores = new ArrayList<>();

            if (cbCalabresa.isChecked()) sabores.add("Calabresa");
            if (cbMarguerita.isChecked()) sabores.add("Marguerita");
            if (cbFrango.isChecked()) sabores.add("Frango com Catupiry");
            if (cbQueijos.isChecked()) sabores.add("Quatro Queijos");
            if (cbBaiana.isChecked()) sabores.add("Baiana");

            if (sabores.isEmpty()) {
                Toast.makeText(this, getString(R.string.erro_sabor), Toast.LENGTH_SHORT).show();
            } else {
                Intent intent = new Intent(this, TamanhoPagamentoActivity.class);
                intent.putStringArrayListExtra("sabores", sabores);
                startActivity(intent);
            }
        });
    }
}
