package com.example.pizzaria;

import android.content.Intent;
import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;

public class TamanhoPagamentoActivity extends AppCompatActivity {

    RadioGroup rgTamanho, rgPagamento;
    Button btnFinalizar;
    ArrayList<String> sabores;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tamanho_pagamento);

        rgTamanho = findViewById(R.id.rgTamanho);
        rgPagamento = findViewById(R.id.rgPagamento);
        btnFinalizar = findViewById(R.id.btnFinalizar);
        sabores = getIntent().getStringArrayListExtra("sabores");

        btnFinalizar.setOnClickListener(v -> {
            int idTamanho = rgTamanho.getCheckedRadioButtonId();
            int idPagamento = rgPagamento.getCheckedRadioButtonId();

            if (idTamanho == -1 || idPagamento == -1) {
                Toast.makeText(this, getString(R.string.erro_pizza), Toast.LENGTH_SHORT).show();
                return;
            }

            String tamanho = "";
            double valor = 0;

            if (idTamanho == R.id.rbPequena) {
                tamanho = "Pequena";
                valor = 30.0;
            } else if (idTamanho == R.id.rbMedia) {
                tamanho = "Média";
                valor = 40.0;
            } else if (idTamanho == R.id.rbGrande) {
                tamanho = "Grande";
                valor = 50.0;
            }

            String pagamento = (idPagamento == R.id.rbDinheiro) ? "Dinheiro" : "Cartão";

            StringBuilder resumo = new StringBuilder();
            resumo.append("Tamanho: ").append(tamanho).append("\n");
            resumo.append("Sabores: ").append(String.join(", ", sabores)).append("\n");
            resumo.append("Pagamento: ").append(pagamento).append("\n");
            resumo.append("Valor total: R$ ").append(String.format("%.2f", valor));

            Toast.makeText(this, resumo.toString(), Toast.LENGTH_LONG).show();
        });
    }
}
